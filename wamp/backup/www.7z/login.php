<?php
$db_hostname='localhost';
$db_database='class_network';
$db_username='root';
$db_password='';
?>