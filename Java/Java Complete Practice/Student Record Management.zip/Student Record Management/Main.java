import java.io.*; 
class Main extends Functions
{
  static Declarations de=new Declarations();
   void main()throws IOException
 {
  de.assign();   
  func();
 }
}