#define NUM 257
#define OPER 258
#define UNARYMINUS 259
