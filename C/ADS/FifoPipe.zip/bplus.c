/*
Ahmed Sabeeh
2016CS16
*/

/*
Question 1. Write a program to implement B+ Tree for N=4.
*/
#include<stdio.h>
#define N 4
struct node
{
	int key[4];
	struct node *point[5];
	int size;
};

struct node *root;

int insert(int n)
{
	return 0;
}

int delete(int n)
{
	return 0;
}

void display()
{
	if(root==NULL)
	{
		printf("Nothing to display\n");
		return;
	}
	
}

void main()
{
	int ch;
	root=(struct node*)malloc(sizeof(struct node));
	
	while(ch!=4)
	{
		printf("Choose\n1. insert\n2. delete\n3. display\n4. exit\n");
		scanf("%d",&ch);
		switch(ch)	
		{
			case 1: printf("Enter number: ");
					scanf("%d",&a);
					a=insert(a);
					if(a==0)
						printf("Inserted\n");
					else
						printf("Error! %d\n",a);
					break;
			case 2: printf("Enter number: ");
					scanf("%d",&a);
					a=delete(a);
					if(a==0)
						printf("Deleted\n");
					else
						printf("Error! %d\n",a);
					break;
			case 3: display();
					break;
			case 4: break;		
			default: printf("Wrong Input Try Again!\n")
		}
	}
}
