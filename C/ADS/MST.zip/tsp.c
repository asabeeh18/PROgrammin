/*
Ahmed Sabeeh
2016CS16
*/

/*
Travelling Salesman Algorithm
*/
#include<stdio.h>
#define N 10
int MAX=99999;
int route[N]={0},a[N][N],vis[N]={0};
int tsp(int cost,int cur,int pos,int n)
{
	int i,cOld=MAX,c;
	//NO PATH ._.
	if(pos==n-1 && a[cur][0]==0)
		return MAX;
	//found way back
	else if(pos==n-1)
	{
		route[pos]=cur;
		return cost+a[cur][0];
	}
	vis[cur]=1;

	route[pos]=cur;
	for(i=0;i<n;i++)
	{
		if(vis[i]==0)
		{
			c=tsp(cost+a[cur][i],i,pos+1,n);
			if(c<cOld)
			{
				cOld=c;
				route[pos]=cur;
			}
		}
	}
	vis[cur]=0;
}
void main()
{
    int a[N][N],n,i,j,c;
    printf("No.of vertices: ");
    scanf("%d",&n);
	printf("Enter weight matrix\n");
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
        	scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(a[i][j]==0)
                a[i][j]=MAX;
        }
    }


    c=tsp(0,0,0,n);
    printf("Route=");
    for(i=0;i<n;i++)
    {
		printf("%d-",route[i]);
	}
}

