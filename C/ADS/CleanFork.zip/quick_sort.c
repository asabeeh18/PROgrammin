//Quick Sort
#include<stdio.h>
int partition(int a[],int left,int right)
{
	int i=left,j=right,x=a[left],t;
	while(a[i]<=x && i<left)
		i++;
	while(a[j]>x)
		j--;
	if(i<j)
	{
		t=a[i];
		a[i]=a[j];
		a[j]=t;
	}
	a[left]=a[j];
	a[j]=x;	
	return j;
}
void quickSort(int a[],int left, int right)
{        
   if(right-left <= 0)
   {
      return;   
   }else {
      int pivot = a[right];
      int partitionPoint = partition(a,left, right, pivot);
      quickSort(a,left,partitionPoint-1);
      quickSort(a,partitionPoint+1,right);
   }        
}   
void display(int n,int* a)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n");
}
void main(int argc,char* argv[])
{
	if(argc<1)
	{
		printf("Usage:(list of integers)");
		return;
	}
	
	int a[argc];
	int i;
	printf("argc: %d\n",argc);
	for(i=0;i<argc;i++)
	{
		a[i]=atoi(argv[i]);
		//printf("%d\n",a[i]);
	}
	for(i=0;i<argc;i++)
	{
		printf("%d ",a[i]);
	}
	quickSort(a,0,argc-1);
	//printf("\n");
	display(argc,a);	
}
