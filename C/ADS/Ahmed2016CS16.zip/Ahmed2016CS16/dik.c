/*
Ahmed Sabeeh
2016CS16
*/

#include <stdio.h>

#define false 0
#define true 1
int V;
int dist[512];
// minimum distance from the remaining vertices
int minDistance(int visited[]) 
{
	int v;
	// Initialize min value
	int min = 9999, min_index;

	for (v = 0; v < V; v++)
		if (visited[v] == false && dist[v] <= min)
			min = dist[v], min_index = v;

	return min_index;
}

void dijkstra(int graph[V][V], int src) 
{
	int i, count, u, v;
	int visited[V]; // true if it is included in path

	for (i = 0; i < V; i++)
	{
		dist[i] = 9999;
		visited[i] = false;
	}
	
	dist[src] = 0;

	// Find shortest path for all vertices
	for (count = 0; count < V ; count++) 
	{
		// minimum distance vertex not yet included
		u = minDistance(visited);

		// Mark the picked vertex as processed
		visited[u] = true;

		// Update dist value of the adjacent vertices of the picked vertex.
		for (v = 0; v < V; v++)
		{
			//not in set , edge exists, new dist is smaller
			//dist[u] != 9999 && 
			if (!visited[v] && graph[u][v] && dist[u]+graph[u][v]<dist[v])
				dist[v] = dist[u] + graph[u][v];
		}
	}
}

int main() 
{
	int a[512][512];
	int e, x, y, i, j, k, w;
	printf("Enter the number of vertices: ");
	scanf("%d", &V);
	printf("Enter the number of edges: ");
	scanf("%d", &e);
	printf("Enter the Edges in format vertex1 vertex2 weight: ");
	
	for(i=0;i<=V;i++)
		for(j=0;j<=V;j++)
			a[i][j]=0;
	for(i=0;i<e;i++)
	{
		scanf("%d %d %d",&x,&y,&w);
		a[x][y]=w;
		a[y][x]=w;
	}
	dijkstra(a, 0);

	printf("Source: 0\nVertex   Distance from Source\n");
	for (i = 0; i < V; i++)
		printf("%d \t\t %d\n", i, dist[i]);

	return 0;
}

