/*
Ahmed Sabeeh
2016CS16
*/
/*
Write C program to implement Dijkstra's algorithm to find the shortest path.
*/
#include<stdio.h>
void main()
{
	int a[512][512];
	int v,e,x,y,i,j,k,w;
	printf("Enter the number of vertices: ");
	scanf("%d",&v);
	printf("Enter the number of edges: ");
	scanf("%d",&e);
	printf("Enter the Edges in fromat vertex1 vertex2 weight: ");
	
	for(i=0;i<=v;i++)
		for(j=0;j<=v;j++)
			a[i][j]=99999;
	for(i=0;i<=v;i++)
		a[i][i]=0;
		
	for(i=0;i<e;i++)
	{
		scanf("%d %d %d",&x,&y,&w);
		a[x][y]=w;
		//a[y][x]=w;		
	}
		
}
