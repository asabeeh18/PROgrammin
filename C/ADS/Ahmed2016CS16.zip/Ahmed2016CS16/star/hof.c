#include <stdio.h>
#include <stdlib.h>
#include<math.h>

#define MAX_TREE_HT 100

// A Huffman tree node
struct MinHeapNode
{
	char data;
	unsigned freq;
	struct MinHeapNode *left, *right;
};

struct MinHeap
{
	unsigned size; // Current size of min heap
	unsigned capacity;
	struct MinHeapNode **array;
};

int count_bits[100];
int counter=0;

struct MinHeapNode* newNode(char data, unsigned freq)
{
	struct MinHeapNode* temp =
		(struct MinHeapNode*) malloc(sizeof(struct MinHeapNode));
	temp->left = temp->right = NULL;
	temp->data = data;
	temp->freq = freq;
	return temp;
}


struct MinHeap* createMinHeap(unsigned capacity)
{
	struct MinHeap* minHeap =
		(struct MinHeap*) malloc(sizeof(struct MinHeap));
	minHeap->size = 0; // current size is 0
	minHeap->capacity = capacity;
	minHeap->array =
	(struct MinHeapNode**)malloc(minHeap->capacity * sizeof(struct MinHeapNode*));
	return minHeap;
}


void swapMinHeapNode(struct MinHeapNode** a, struct MinHeapNode** b)
{
	struct MinHeapNode* t = *a;
	*a = *b;
	*b = t;
}


void minHeapify(struct MinHeap* minHeap, int idx)
{
	int smallest = idx;
	int left = 2 * idx + 1;
	int right = 2 * idx + 2;

	if (left < minHeap->size &&
		minHeap->array[left]->freq < minHeap->array[smallest]->freq)
	smallest = left;

	if (right < minHeap->size &&
		minHeap->array[right]->freq < minHeap->array[smallest]->freq)
	smallest = right;

	if (smallest != idx)
	{
		swapMinHeapNode(&minHeap->array[smallest], &minHeap->array[idx]);
		minHeapify(minHeap, smallest);
	}
}


int isSizeOne(struct MinHeap* minHeap)
{
	return (minHeap->size == 1);
}


struct MinHeapNode* extractMin(struct MinHeap* minHeap)
{
	struct MinHeapNode* temp = minHeap->array[0];
	minHeap->array[0] = minHeap->array[minHeap->size - 1];
	--minHeap->size;
	minHeapify(minHeap, 0);
	return temp;
}


void insertMinHeap(struct MinHeap* minHeap, struct MinHeapNode* minHeapNode)
{
	++minHeap->size;
	int i = minHeap->size - 1;
	while (i && minHeapNode->freq < minHeap->array[(i - 1)/2]->freq)
	{
		minHeap->array[i] = minHeap->array[(i - 1)/2];
		i = (i - 1)/2;
	}
	minHeap->array[i] = minHeapNode;
}

void buildMinHeap(struct MinHeap* minHeap)
{
	int n = minHeap->size - 1;
	int i;
	for (i = (n - 1) / 2; i >= 0; --i)
		minHeapify(minHeap, i);
}


void printArr(int arr[], int n)
{
    int count=0;
	int i;
	for (i = 0; i < n; ++i){
		printf("%d", arr[i]);
		count++;
	}
	count_bits[counter++]=count;
	printf("\n");
}


int isLeaf(struct MinHeapNode* root)
{
	return !(root->left) && !(root->right) ;
}


struct MinHeap* createAndBuildMinHeap(char data[], int freq[], int size)
{
	struct MinHeap* minHeap = createMinHeap(size);
	int i;
	for (i = 0; i < size; ++i)
		minHeap->array[i] = newNode(data[i], freq[i]);
	minHeap->size = size;
	buildMinHeap(minHeap);
	return minHeap;
}

// The main function that builds Huffman tree
struct MinHeapNode* buildHuffmanTree(char data[], int freq[], int size)
{
	struct MinHeapNode *left, *right, *top;

	// Step 1: Create a min heap of capacity equal to size. Initially, there are
	// modes equal to size.
	struct MinHeap* minHeap = createAndBuildMinHeap(data, freq, size);

	// Iterate while size of heap doesn't become 1
	while (!isSizeOne(minHeap))
	{
		// Step 2: Extract the two minimum freq items from min heap
		left = extractMin(minHeap);
		right = extractMin(minHeap);

		// Step 3: Create a new internal node with frequency equal to the
		// sum of the two nodes frequencies. Make the two extracted node as
		// left and right children of this new node. Add this node to the min heap
		// '$' is a special value for internal nodes, not used
		top = newNode('$', left->freq + right->freq);
		top->left = left;
		top->right = right;
		insertMinHeap(minHeap, top);
	}

	// Step 4: The remaining node is the root node and the tree is complete.
	return extractMin(minHeap);
}

// Prints huffman codes from the root of Huffman Tree. It uses arr[] to
// store codes
void printCodes(struct MinHeapNode* root, int arr[], int top)
{
	// Assign 0 to left edge and recur
	if (root->left)
	{
		arr[top] = 0;
		printCodes(root->left, arr, top + 1);
	}

	// Assign 1 to right edge and recur
	if (root->right)
	{
		arr[top] = 1;
		printCodes(root->right, arr, top + 1);
	}

	// If this is a leaf node, then it contains one of the input
	// characters, print the character and its code from arr[]
	if (isLeaf(root))
	{
		printf("%c: ", root->data);
		printArr(arr, top);
	}
}

// The main function that builds a Huffman Tree and print codes by traversing
// the built Huffman Tree
void HuffmanCodes(char data[], int freq[], int size)
{
// Construct Huffman Tree
struct MinHeapNode* root = buildHuffmanTree(data, freq, size);

// Print Huffman codes using the Huffman tree built above
int arr[MAX_TREE_HT], top = 0;
printCodes(root, arr, top);
}

// Driver program to test above functions
int main()
{

    char *sym;
    int freq[100];
    float prob[100];
    int size,i;
    printf("Enter no. of symbols:\n");
        scanf("%d",&size);
    sym=(char *)malloc((size+1)*sizeof(char));
    //for(i=0;i<size;i++)
      //  scanf("%c",arr[i]);
      scanf("%s",sym);
    for(i=0;i<size;i++)
    {
        scanf("%d",&freq[i]);
    }
	for(i=0;i<size;i++)
    {
        prob[i]=((float)freq[i])/100;
    }
    for(i=0;i<size;i++)
    {
        printf("%f\n",prob[i]);
    }
    HuffmanCodes(sym, freq, size);

    //Entropy
    float entropy=0;
    for(i=0;i<size;i++)
    {
        float lg=log(prob[i]);
        entropy+=prob[i]*lg;
    }
    entropy=-1.0*entropy;
    printf("\n Entropy= %f\n",entropy);

	//Average Code word Length
    for(i=0;i<size;i++)
    {
        printf("%d\n",count_bits[i]);
    }
    float avg_code_word_length=0;
    for(i=0;i<size;i++)
    {
        avg_code_word_length+=prob[i]*count_bits[i];
    }
    printf("\n Average Code word Length= %f\n",avg_code_word_length);

    //EFFICIENCY
    float efficiency;
    efficiency=entropy/avg_code_word_length;
    printf("Efficiency= %f\n",efficiency);

    //String From huffman code


	return 0;
}
