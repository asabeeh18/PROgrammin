/* 
Ahmed Sabeeh
2016CS16
*/
//Implement avl tree (insertion, searching, and deletion)
//DOES NOT WORK
#include<stdio.h>
#include<malloc.h>
struct Tree
{
	int a;
	struct Tree *right,*left;
};
struct Tree *root;

void rotateRight(struct Tree *top)
{
	struct Tree *temp,*t;
	t=top->left;
	temp=top->left->right;
	top->left->right=top;
	top->left=temp;
	top=t;
}

void rotateLeft(struct Tree *top)
{
	struct Tree *temp,*t;
	t=top->right;
	temp=top->right->left;
	top->right->left=top;
	top->right=temp;
	top=t;
}

int height(struct Tree *top)
{
	if(top==NULL)
		return 0;
		
	int hLeft,hRight;
	hLeft=height(top->left);
	hRight=height(top->right);		
	int h=hLeft>hRight?hLeft:hRight;
	
	return (1+h);
}

struct Tree* balancer(struct Tree *top)
{
	int hLeft,hRight;
	if(top==NULL)
		return;
		
		
	hLeft=height(top->left);
	hRight=height(top->right);	
	//fix it
	if(hLeft>hRight)
	{
		if(hLeft>hRight+1)
		{
			//double pointer might help?
			rotateRight(top);
		}
	}

	if(hLeft<hRight)
	{
		if(1+hLeft<hRight)
		{
			rotateLeft(top);
		}
	}
	else
	{
		//TROUBLE
		top->left=balancer(top->left);
		top->right=balancer(top->right);
	}
	return top;
}


void inorder(struct Tree *top)
{
	if(top==NULL)
		return;
	inorder(top->left);
	printf("%d ",top->a);	
	inorder(top->right);
}


void insert(int a,struct Tree *top)
{
	if(a<=top->a)
	{
		if(top->left!=NULL)
			insert(a,top->left);
		else
		{
			top->left=(struct Tree*)malloc(sizeof(struct Tree));
			top->left->a=a;
		}
	}
	else
	{
		if(top->right!=NULL)
			insert(a,top->right);
		else
		{
			top->right=(struct Tree*)malloc(sizeof(struct Tree));
			top->right->a=a;
		}

	}
	top=balancer(top);
	printf("\nIn Insert!\n");
	inorder(root);
	printf("\n\n");

}

struct Tree* search(int a, struct Tree *top)
{
	if(top==NULL)
		return NULL;
	if(top->a==a)
		return top;
	if(top->a<a)
	{
		return search(a,top->right);
	}
	else
	{
		return search(a,top->left);
	}
}
void delete(int a,struct *Tree top)
{
	
}
void main()
{
	int n,a,i;
	struct Tree* temp;
	printf("Enter number of elements: ");
	scanf("%d",&n);
	printf("Enter elements\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a);
		if(root==NULL)
		{
			root=(struct Tree*)malloc(sizeof(struct Tree));
			root->a=a;
		}
		else
			insert(a,root);
	}
	printf("Inserted!\n");
	printf("Enter element to search: ");
	scanf("%d",&a);
	temp=search(a,root);
	if(temp!=NULL)
		printf("Element %d found at %x\n",temp->a,temp);
	else
		printf("Element not found\n");
		
	printf("Enter element to delete: ");
	scanf("%d",&a);	
	temp=delete(a,root);
	if(temp!=NULL)
		printf("Element was deleted\n");
	inorder(root);
	printf("\nExit!\n");
}
