/*
Question: Write program for stack, queue, linked list, and doubly linked list.
Stack using array
*/

#include<stdio.h>
#define N 10
int top=-1;

int push(int *a,int n)
{
    if(top>=N-1)
        return 0;
    top++;
    a[top]=n;
    return 1;
}

int pop(int *a)
{
    int n;
    n=a[top];
    top--;
    return n;
}

void display(int *a)
{
    int i=0;
    for(i=0;i<=top;i++)
    {
        printf("%d ",a[i]);
    }
        printf("\n");    
}

void main()
{
    int a[N],ch=0,status;       
    while(ch!=4)
    {
        printf("1. Push\n2. Pop\n3. Display\n4. Exit\n");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1: printf("Enter: ");
                    scanf("%d",&ch);
                    status=push(a,ch);
                    if(status!=1)
                    {
                        printf("Stack overflow!\n");
                    }
                    ch=0;
                    break;
            case 2: if(top==-1)
                    {
                        printf("Stack underflow!\n");
                    }
                    else
                    {
                        ch=pop(a);
                        printf("Popped Element: %d\n",ch);
                        ch=0;
                    }
                    
                    break;
            case 3: display(a);
                    break;
            case 4: break;
            default: printf("Try Again!");
                            
        }
    }
}
