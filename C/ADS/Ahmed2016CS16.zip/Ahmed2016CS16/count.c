/*
Ahmed Sabeeh
2016CS16
*/
/*
Implementation of a program to count number of lines, printf statements and number of functions used in a directory of files.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>

int tlines=0, tpf=0,tfunctions=0,fC=0;

int lineCounter(char path[])
{
	fC++;
    FILE *fp;
    int lCount = 0;
    char c;

    fp = fopen(path, "r");

    if (fp == NULL)
    {
    	printf("Could not open file\n");
        return 0;
    }

    // Extract characters from file and store in character c
    for (c = getc(fp); c != EOF; c = getc(fp))
            if (c == '\n') // Increment count if this character is newline
                    lCount++;
    fclose(fp);
    return lCount;
}

//Function to count number of printf statement in a file
int countPrint(char path[],int count)
 {
     char buffer[1024];
     FILE *fp;
	 int printcount = 0;//counter for count number of printf function
	 int j;
     fp = fopen(path, "r");

	 for(j=0;j< count;j++) {
        fgets(buffer,1023,fp);
	    if(strstr(buffer,"printf(")!= NULL)//If the string contains "printf" substring, it increases counter
		    printcount++;
	}

    fclose(fp);
    return printcount;
}

/*
 * Function to count number of functions in a file.
 */
int countFunctions(char path[])
{
    char buff[500],command[500];
    sprintf(command,"%s%s%s","ctags -x --c-types=f ",path," | wc -l");// Extract Functions used in a file & count it
    FILE *cmd = popen(command, "r");
    fgets(buff,1023,cmd);
    return atoi(buff);
}
//Function to read directory contents
void DirRead(char dirPath[]) {
    DIR *dp = NULL;
	struct dirent *dir;

    int status;
    struct stat st_buf;
	char files[50][50];
	int nFiles = 0;



	dp = opendir((const char *)dirPath);
	if(dp == NULL)
	{
		printf("\nCan not open a directory");
		exit(0);
	}
    while((dir = readdir(dp)) != NULL)
    {
		if(dir->d_name[0] != '.' && dir->d_name[strlen(dir->d_name) - 1] != '~' )
		{
			char path[400];
		    strcpy(path,dirPath);
		    strcat(path,"/");

		    strcat(path,dir->d_name);
		    status = stat(path, &st_buf); //To save status of file in st_buf
		    if (S_ISDIR(st_buf.st_mode)) 
		    { //to check whether the file is  a directory or not..

		        printf ("\ndirectory: %s", dir->d_name);
		        DirRead(path);				//Recursively read subdirectory in directory
		    }
		    else 
		    {
		    	//count number of lines ,prinf statements and functions for c file only.
	        	if((st_buf.st_mode & S_IXUSR) == 0 && strstr(dir->d_name,".c") != NULL) 
	            {
	                int count = lineCounter(path);
	                int pfc = countPrint(path,count);
					int funct=countFunctions(path);

					printf("\n\t%s\n\t\tLine of Code: %d ", dir->d_name, count);
					printf("\n\t\tNumber of printf Statements: %d",pfc);

//					printf("\nNumber of Functions = %d", funct);
					tlines +=count;//Total line of code in directory
					tpf +=pfc;     //Total printf statement used in directory
					tfunctions +=funct; //Total number of functions used in directory
	             }
		     }
	     }
	}
}

int main()
{
	char dirPath[100] = "/home/user/Ahmed2016CS16";
    DirRead(dirPath);
	printf("\n\n======================================\n\n");
    printf("\n=====Complete Analysis=====\n");
	printf("\nTotal Lines Of Code: %d\nTotal printf statement: %d\nTotal File Count: %d\n", tlines,tpf,fC);
	return 0;
}

