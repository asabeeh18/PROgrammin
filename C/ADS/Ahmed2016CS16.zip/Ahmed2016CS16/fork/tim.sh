ctime=`stat -c %Y fork2.c`
otime=`stat -c %Y fork2.o`
echo if [ $ctime -nt $otime ];

