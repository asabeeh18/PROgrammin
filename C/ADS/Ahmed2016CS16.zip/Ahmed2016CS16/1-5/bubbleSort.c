/*
Ahmed Sabeeh
2016CS16

Question: Write a C program to implement bubble sort for following input types:
(i). Integer
(ii). String
(iii). Date (Day/Month/Year where Month is either string, such as August or integer, such as 08) 
All these data are stored in file. Your program should read input from one file and store sorted output in another file. Find the execution time of program for each input type. While writing the program, follow the software engineering principle as you studied in your UG/PG courses.

(i). Integer
*/
#include<stdio.h>
void main()
{
	int bf[100];
	//input and output file
	FILE *input;//=fopen("ints","r+");
	FILE *output;//=fopen("ints-outs","w");
	char s[256];
	int i,j,tmp,n;
	int a[50];
	
	//input	
	printf("Enter input file name containing integers, Space or new line seperated: ");
	scanf("%s",s);
	input=fopen(s,"r+");
	printf("Enter output file name: ");
	scanf("%s",s);
	output=fopen(s,"w");

	//process
	i=0;
	while(!feof(input))
	{
		fscanf(input,"%d",&bf[i]);
		i++;
	}
	n=i-1;

	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(bf[j]>bf[j+1])
			{
				tmp=bf[j+1];
				bf[j+1]=bf[j];
				bf[j]=tmp;
			}
		}
	}
	
	//Output
	for(i=0;i<n;i++)
		fprintf(output,"%d ",bf[i]);
	printf("Done!! Output saved in file: %s\n",s);
}
/*void print()
{
	for(i=0;i<n;i++)
		printf("%d ",bf[i]);
}*/
