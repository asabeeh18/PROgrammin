#include<stdio.h>
void main()
{
	printf("Total lines of C code in current directory:");
	system("( find ./ -name '*.c' -print0 | xargs -0 cat ) | wc -l");
}
