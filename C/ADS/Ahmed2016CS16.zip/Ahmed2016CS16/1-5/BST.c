/* 
Ahmed Sabeeh
2016CS16
*/

//Binary Search Tree using structure

#include<stdio.h>
#include<malloc.h>

struct Tree
{
	int a;
	struct Tree *right,*left;
};

void preorder(struct Tree *root)
{
	if(root==NULL)
		return;
	printf("%d ",root->a);
	preorder(root->left);
	preorder(root->right);
}
void postorder(struct Tree *root)
{
	if(root==NULL)
		return;
	postorder(root->left);
	postorder(root->right);
	printf("%d ",root->a);
}
void inorder(struct Tree *root)
{
	if(root==NULL)
		return;
	inorder(root->left);
	printf("%d ",root->a);	
	inorder(root->right);
}
void insert(int a,struct Tree *root)
{
	if(a<=root->a)
	{
		//Number is less than or equal to current Node.Insert in left subtree
		if(root->left!=NULL)
			insert(a,root->left);
		else
		{
			root->left=(struct Tree*)malloc(sizeof(struct Tree));
			root->left->a=a;
		}
	}
	else
	{
		//Number is greater than current Node.Insert in right subtree
		if(root->right!=NULL)
			insert(a,root->right);
		else
		{
			root->right=(struct Tree*)malloc(sizeof(struct Tree));
			root->right->a=a;
		}

	}
}
//count number of elements
int count(struct Tree *root)
{
	if(root==NULL)
		return 0;
	//Bottom up calculation
	return (1+count(root->left)+count(root->right));
}

void levelOrder(struct Tree *root,int n)
{
	
	int i=0,top=0;
	//Array of tree nodes
	struct Tree *q[n];
	int a[n];

	q[top]=(struct Tree*)malloc(sizeof(struct Tree));
	q[top]=root;
	//Insert using queue structure
	while(top<n)
	{
		root=q[top];
		if(root->left!=NULL)
		{
			//Store Left Node
			q[++i]=(struct Tree*)malloc(sizeof(struct Tree));
			q[i]=root->left;
		}
		if(root->right!=NULL)
		{
			//Store Right Node
			q[++i]=(struct Tree*)malloc(sizeof(struct Tree));
			q[i]=root->right;	
		}
		top++;
	}
	
	//Print in level order format
	for(i=0;i<n;i++)
	{
		printf("%d ",q[i]->a);
	}
}

void main()
{
	int n,a,i,e;
	struct Tree *root;
	printf("Enter number of elements: ");
	e=scanf("%d",&n);
    if(e!=1)
	{
		printf("Illegal input!!\n");
		getchar();
		main();
		return;
	}

	for(i=0;i<n;i++)
	{
		e=scanf("%d",&a);
		if(e!=1)
		{
			printf("Illegal input!!\n");
			getchar();
			i--;
		}

		if(root==NULL)
		{
			root=(struct Tree*)malloc(sizeof(struct Tree));
			root->a=a;
		}
		else
			insert(a,root);
	}
	printf("Inserted!\n");
	printf("\nPreorder\n");
	preorder(root);
	printf("\nPostorder\n");
	postorder(root);
	printf("\nInorder\n");
	inorder(root);
	printf("\nLevelorder\n");
	n=count(root);
	levelOrder(root,n);
	printf("\nExit!\n");
}
