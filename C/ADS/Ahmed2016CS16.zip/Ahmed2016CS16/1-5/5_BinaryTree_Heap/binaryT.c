/* 
Ahmed Sabeeh
2016CS16
*/

//Binary Tree using structure
#include<stdio.h>
#include<malloc.h>
#include<limits.h>
struct Tree
{
	int a;
	struct Tree *right,*left;
};

//Takes unwanted input
char trash[1024];

void preorder(struct Tree *root)
{
	if(root==NULL)
		return;
	printf("%d ",root->a);
	preorder(root->left);
	preorder(root->right);
}

void postorder(struct Tree *root)
{
	if(root==NULL)
		return;
	postorder(root->left);
	postorder(root->right);
	printf("%d ",root->a);
}

void inorder(struct Tree *root)
{
	if(root==NULL)
		return;
	inorder(root->left);
	printf("%d ",root->a);
	inorder(root->right);
}

void readTree(struct Tree *root)
{
	int ch,e;
	printf("Enter Root Element(Number): ");
	e=scanf("%d",&root->a);
	if(e!=1)
	{
		//Catch wrong/unwanted input
		scanf("%[^\n]s",trash);
		getchar();
		printf("Invalid Number! Try Again\n");
		readTree(root);
		return;
	}
	while(1)
	{
		printf("Choose\n");
		if(root->right==NULL)
		{
			printf("1. Right subtree\n");
		}
		if(root->left==NULL)
		{
			printf("2. Left subtree\n");
		}
		printf("3. Move up (Can't come back in this branch again!)\n");
		e=scanf("%d",&ch);
		if(e!=1)
		{

			getchar() != '\n';
			//printf("\n%d\n",ch);
			ch=4;
		}
		switch(ch)
		{
			case 1: //Generate Right subtree
					root->right=(struct Tree*)malloc(sizeof(struct Tree));
					readTree(root->right);
					break;
			case 2: //Generate Left subtree
					root->left=(struct Tree*)malloc(sizeof(struct Tree));
					readTree(root->left);
					break;
			case 3:
					return;
			default: printf("Wrong choice! Try Again!");
		}
	}
}

//count number of elements
int count(struct Tree *root)
{
	if(root==NULL)
		return 0;
	//Bottom up calculation
	return (1+count(root->left)+count(root->right));
}

void levelOrder(struct Tree *root,int n)
{
	
	int i=0,top=0;
	//Array of tree nodes
	struct Tree *q[n];
	int a[n];

	q[top]=(struct Tree*)malloc(sizeof(struct Tree));
	q[top]=root;
	//Insert using queue structure
	while(top<n)
	{
		root=q[top];
		if(root->left!=NULL)
		{
			//Store Left Node
			q[++i]=(struct Tree*)malloc(sizeof(struct Tree));
			q[i]=root->left;
		}
		if(root->right!=NULL)
		{
			//Store Right Node
			q[++i]=(struct Tree*)malloc(sizeof(struct Tree));
			q[i]=root->right;	
		}
		top++;
	}
	
	//Print in level order format
	for(i=0;i<n;i++)
	{
		printf("%d ",q[i]->a);
	}
}

void main()
{
	int n,i,a;
	struct Tree *root;

	//read
	root=(struct Tree*)malloc(sizeof(struct Tree));
	readTree(root);
	
	//output
	printf("\nPreorder\n");
	preorder(root);
	printf("\nPostorder\n");
	postorder(root);
	printf("\nInorder\n");
	inorder(root);
	printf("\nLevelorder\n");
	
	n=count(root);
	levelOrder(root,n);
	printf("\nExit!\n");
}
