/*
Ahmed Sabeeh
2016CS16

Question: Write a C program to implement bubble sort for following input types:
(i). Integer
(ii). String
(iii). Date (Day/Month/Year where Month is either string, such as August or integer, such as 08) 
All these data are stored in file. Your program should read input from one file and store sorted output in another file. Find the execution time of program for each input type. While writing the program, follow the software engineering principle as you studied in your UG/PG courses.

(iii). Date
*/
#include<stdio.h>
#include<string.h>
/*
union Month
{
	int mnthint;
	char mnthstr[50];
};
*/
struct Date
{
	int day;
	int year;
	int month;   	
};
void main()
{
	char bf[100];
	FILE *input;
	FILE *output;
	int i,j,n;
	int a[50];
	struct Date date[50];
	struct Date tmp;
	char s[256];
	
	//Input
	printf("Enter input file name containing Dates in format dd/mm/yyyy, Space or new line seperated: ");
	scanf("%s",s);
	input=fopen(s,"r+");
	printf("Enter output file name: ");
	scanf("%s",s);
	output=fopen(s,"w");
	
	i=0;
	while(!feof(input))
	{
		if(!fscanf(input,"%d/%d/%d",&date[i].day,&date[i].month,&date[i].year))
			break;
		i++;
	}
	n=i-1;
	

	//Process
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(date[j].year>date[j+1].year)
			{
				tmp=date[j];
				date[j]=date[j+1];
				date[j+1]=tmp;		
			}
			else if(date[j].month>date[j+1].month && date[j].year==date[j+1].year)
			{
				tmp=date[j];
				date[j]=date[j+1];
				date[j+1]=tmp;		
			}
			else if(date[j].day>date[j+1].day && date[j].month==date[j+1].month && date[j].year==date[j+1].year)
			{
				tmp=date[j];
				date[j]=date[j+1];
				date[j+1]=tmp;		
			}
		}
	}
	
	//Output
	for(i=0;i<n;i++)
		fprintf(output,"%d/%d/%d ",date[i].day,date[i].month,date[i].year);
	printf("Done!! Output saved in file: %s\n",s);
}
/*void print()
{
	for(i=0;i<n;i++)
		printf("%d ",bf[i]);
}*/	
