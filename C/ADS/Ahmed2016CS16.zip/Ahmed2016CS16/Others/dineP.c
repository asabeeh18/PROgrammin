/*
Ahmed Sabeeh
*/
/*
Dining Philosopher using semget
Dijkstras solution

Philospher picks up the lower numbered fork(spoon)

*/
#include<stdio.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<semaphore.h>
#define N 5
int philosopher=N,spoon=N;
//int spoon[N];
sem_t spoon[N];
philosopher(int i)
{
	if(i==0)
		while(1)
		{
			printf("Philosopher %d Starts to think",i);
			sem_wait(&spoon[i]);
			sem_wait(&spoon[N-1]);
				printf("Philosopher %d Eats",i);
				sleep(50);
			sem_post(&spoon[N-1]);	
			sem_wait(&spoon[i]);
		}
	else
		while(1)
		{
			sem_wait(&spoon[i-1]);
			sem_wait(&spoon[i]);
				printf("Philosopher %d Eats",i);
				sleep(50);
			sem_wait(&spoon[i]);
			sem_post(&spoon[i-1]);
		}
}
void main()
{
	pthread_t thr[N];
	key_t key =1234;
	int semid=semget(key,N,IPC_CREAT|0666);
	
	ret = semctl( semid, N, SETVAL, sem);
	if (ret == 1)
		 perror("Semaphore failed to initialize");

	sem_init(spoon,0,1)
	for(i=0;i<N;i++)
	{
		pthread_create(&thr[i], NULL, phiosopher,i);
	}				
    pthread_join(tid, NULL);
}
