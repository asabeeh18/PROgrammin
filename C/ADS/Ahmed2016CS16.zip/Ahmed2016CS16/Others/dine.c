/*
Ahmed Sabeeh
*/
/*
Dining Philosopher using semget
*/
/*  This program is an implementation of the dinning philosophers 
 *  problem: N philosphers sit around a table each with one chop
 *  stick between them.  The problem is to allow philosophers to
 *  both eat and think without deadlock while waiting for a pair of
 *  free chopsticks.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>

#define	SEM_A	0200	/* alter permission */
#define	SEM_R	0400	/* read permission */
#define	SHM_W	0200	/* write permission */
#define	SHM_R	0400	/* read permission */
#define THINKTIME	4
#define LEFTTIME        2              /* time to pick up left chopstick  */
#define RIGHTTIME       2              /*** time to pick up right chopstick  */
#define EATTIME		3
#define PHILOSOPHERS	4

short stick[PHILOSOPHERS+1];		/* semaphore numbers of chopsticks */
short print;				/* semaphore number for output */
short mutex;				/*** semaphore number for mutex */

int procno;				/* private variable to hold id */

/* Structure to be allocated in shared memory.  For now, only keep track
 * who's got which chopstick.
 */
struct shm {
	int whosgot[PHILOSOPHERS];
} *shared;

int semgroup;				/* semaphore group identifier */

/* Dijkstra's down, implemented in terms of System V semaphores.  Also
 * keeps track of who's got the resource, just for convenience.  
 * Down allows a limited number of processes to enter a region.
 */
down(semid) {
	struct sembuf semopr;

	semopr.sem_num = semid;
	semopr.sem_op = -1;
	semopr.sem_flg = 0;
	semop(semgroup, &semopr, 1);

	if (semid <= PHILOSOPHERS)
		shared->whosgot[semid] = procno;
}

/* Dijkstra's up */
up(semid) {
	struct sembuf semopr;

	if (semid <= PHILOSOPHERS)
		shared->whosgot[semid] = -1;

	semopr.sem_num = semid;
	semopr.sem_op = 1;
	semopr.sem_flg = 0;
	semop(semgroup, &semopr, 1);
}

philosopher(n) {
	procno = n;
	for(;;) {
		think();
		eat(procno);
	}
}

msg(s)
char *s;
{
	int i;

	down(print);

	printf("Philosopher %d %s [", procno, s);
	for (i=0; i<PHILOSOPHERS; i++)
	  printf("%d:%d,",i,shared->whosgot[i]);
	printf("]\n");
	up(print);
}

think() {
	msg("begins thinking.");
	sleep(rand() % THINKTIME);
}

eat(n) {
  int odd;
	msg("becomes hungry.");
	down(stick[n+1]);
	msg("has taken her right chopstick.");
	sleep(rand() % RIGHTTIME );
  	down(stick[n]);
	msg("has taken her left chopstick, and begins eating.");
	sleep(rand() % EATTIME);
	up(stick[n+1]);
	up(stick[n]);     
	msg("has returned her chopsticks.");
}

main() {
	int i;
	int shmid;
	int shmret;

	shmid = shmget(IPC_PRIVATE, sizeof(*shared),
			IPC_CREAT|SHM_W|SHM_R);
	printf("shmid: %i \n", shmid);
	shared = (struct shm *)  shmat(shmid, (char *)0, 0);
	semgroup = semget(IPC_PRIVATE, PHILOSOPHERS+3, IPC_CREAT|SEM_A|SEM_R);
	printf("semgroup: %i \n", semgroup);
	for (i=0; i<=PHILOSOPHERS; i++) {
	        up(i);
		stick[i]=i;
		shared->whosgot[i] = -1;
	}
	stick[PHILOSOPHERS] = stick[0];
	up(PHILOSOPHERS+1);
	print =  PHILOSOPHERS+1;
/*** take the philosphers+2 semaphore, set value 1 so first down won't sleep */
	up(PHILOSOPHERS+2);
/*** save number of semaphore in variable mutext for multual exclusion use   */
	mutex =  PHILOSOPHERS+2;
	for (i=1; i<PHILOSOPHERS; i++) {
		if (!fork())
			philosopher(i);
		srand(rand());
	}
	philosopher(0);
}
