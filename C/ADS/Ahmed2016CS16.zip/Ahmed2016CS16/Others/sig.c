/*
Ahmed Sabeeh
2016CS16
*/

/*
Write a C program for each of the following signals demonstrating their utility. You are free to make use of different
system calls in your C program for demonstration of utility.
	SIGALRM - alarm clock
	SIGBUS - bus error
	SIGFPE - floating point arithmetic exception
	SIGINT - interrupt (i.e., Ctrl-C)
	SIGQUIT - quit (i.e., Ctrl-\)
	SIGTERM - process terminated
	SIGUSR1 and SIGUSR2 - user defined signals

*/
void main()
{
	
}
