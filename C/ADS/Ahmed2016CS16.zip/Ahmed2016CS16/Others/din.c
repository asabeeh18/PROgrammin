
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <time.h>

#define N 5
#define LEFT (i+N-1)%N
#define RIGHT (i+1)%N

#define THINKING 0
#define HUNGRY 1
#define EATING 2

#define MUTEX 0

int sem_id;
struct sembuf semaphore;
int *state;            /* This is the shared memory which holds the
                 state of the philosophers.*/
void up(int sem_id,int sem_num,struct sembuf *semaphore) {
  semaphore->sem_num=sem_num;
  semaphore->sem_op=1;
  semaphore->sem_flg=0;
  semop(sem_id,semaphore,1);
}

void down(int sem_id,int sem_num,struct sembuf *semaphore) {
  semaphore->sem_num=sem_num;
  semaphore->sem_op=-1;
  semaphore->sem_flg=0;
  semop(sem_id,semaphore,1);
}

void initSem(int sem_id,int sem_num,int val) {
  union semnum {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
  }argument;
  argument.val=val;
  semctl(sem_id,sem_num,SETVAL,argument);
}

void take_forks(int);
void put_forks(int);
void test(int);

void philosopher(int i) {
  srandom(time(NULL));
  take_forks(i);
  sleep(random()%5);        /* This is the time the philosopher eats */
  put_forks(i);
}
void take_forks(int i) {
  down(sem_id,MUTEX,&semaphore);
  state[i]=HUNGRY;
  test(i);
  up(sem_id,MUTEX,&semaphore);
  down(sem_id,i+1,&semaphore);
}

void put_forks(int i) {
  down(sem_id,MUTEX,&semaphore);
  state[i]=THINKING;
  printf("Philosopher %d is now thinking.\n",i);
  test(LEFT);
  test(RIGHT);
  up(sem_id,MUTEX,&semaphore);
}

void test(i) {
  if(state[i]==HUNGRY && state[LEFT] !=EATING && state[RIGHT]!=EATING) {
    state[i]=EATING;
    printf("Philosopher %d is now eating.\n",i);
    up(sem_id,i+1,&semaphore);
  }
 
}


int main() {
  int i;
  int shm_id;
  key_t shm_key=1234,sem_key=3456;
  shm_id=shmget(shm_key,N,IPC_CREAT|0666);
  sem_id=semget(sem_key,N+1,IPC_CREAT|0666); /* N+1 semaphores for the
                          N philosophers and 1 mutex.*/
  state=shmat(shm_id,NULL,0);
  for(i=0;i<N;i++)
    state[i]=THINKING;
  initSem(sem_id,MUTEX,1);
  for(i=1;i<=N;i++)
    initSem(sem_id,i,0);

  /* Fork 5 philosophers. */

  if(!fork()) {
    philosopher(0);
  }
  else {
    if(!fork()) {
      philosopher(1);
    }
    else {
      if(!fork()) {
    philosopher(2);
      }
      else {
    if(!fork()) {
      philosopher(3);
    }
    else {
      philosopher(4);
    }
      }
    }
  }
}


