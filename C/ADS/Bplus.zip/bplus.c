/*
Ahmed Sabeeh
2016CS16
*/

/*
Question 1. Write a program to implement B+ Tree for N=4.
*/
#include<stdio.h>
#include<malloc.h>
#define N 4
struct rec
{
	int a;
};
struct node
{
	int key[N];
	void *point[N+1];
	int num;
	int leaf;
};

struct node *root;

/*
Use at least

Non-leaf: (n+1)/2 pointers

Leaf: (n+1)/2  pointers to data
*/

struct node* leafSearch(struct node *root,int a)
{
	int i = 0;
	struct node *p = root;
	while(p->leaf==0)
	{
		for(i=0;i<N;i++)
		{
			if(a<p->key[i])
			{
				i=-1;
				p=p->point[i];
				break;
			}
		}
		if(i==-1)
		{
			p=p->point[N];
		}
	}
	return p;
}
struct node *leafInsert(struct node *leaf, int a) {

	int i, insertPoint=0;
	while(insertPoint < leaf->num && leaf->key[insertPoint] < a)
		insertPoint++;

	for(i = leaf->num; i > insertPoint; i--) {
		leaf->key[i] = leaf->key[i - 1];
		leaf->point[i] = leaf->point[i - 1];
	}
	leaf->key[insertPoint] = a;
	leaf->point[insertPoint]=malloc(sizeof(int));
	*((int*)leaf->point[insertPoint]) = a;
	leaf->num++;
	return leaf;
}

int insert(int a)
{
	struct node *p;
	int i;
	if(root==NULL)
	{
		root=(struct node*)malloc(sizeof(struct node));
		root->point[0]=(struct rec*)malloc(sizeof(struct rec));
		root->key[0]=a;
		root->point[0]=a;
		root->leaf=1;
		return 0;
	}
	p=leafSearch(root,a);
	if(p->num>=N)
	{
		//Stay away node full
		
		
		printf("\nNope!\n");
		return 0;
	}
	leafInsert(p,a);
	return 1;
}

int delete(int n)
{
	return 0;
}

void display()
{
	if(root==NULL)
	{
		printf("Nothing to display\n");
		return;
	}
	
}

void main()
{
	int ch,a;
	root=(struct node*)malloc(sizeof(struct node));

	while(ch!=4)
	{
		printf("Choose\n1. insert\n2. delete\n3. display\n4. exit\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1: printf("Enter number: ");
					scanf("%d",&a);
					a=insert(a);
					if(a==1)
						printf("Inserted\n");
					else
						printf("Error! %d\n",a);
					break;
			case 2: printf("Enter number: ");
					scanf("%d",&a);
					a=delete(a);
					if(a==0)
						printf("Deleted\n");
					else
						printf("Error! %d\n",a);
					break;
			case 3: display();
					break;
			case 4: break;
			default: printf("Wrong Input Try Again!\n");
		}
	}
}

