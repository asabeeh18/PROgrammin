----

.. table:: Truth table for "not"
  :class: my-table-class

  +------------+------------+
  | Name       | Money Owed |
  +============+============+
  | Adam Alpha | 100        |
  +------------+------------+


.. table::
  :name: my-table

  +------------+------------+
  | Number     | Two        |
  +============+============+
  | Adam Alpha | 100        |
  +------------+------------+
