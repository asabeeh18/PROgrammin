Hovercraft!
===========

.. image:: https://pypip.in/v/hovercraft/badge.png
    :target: https://crate.io/packages/hovercraft/
    :alt: Latest PyPI version

.. image:: https://pypip.in/d/hovercraft/badge.png
    :target: https://crate.io/packages/hovercraft/
    :alt: Number of PyPI downloads

*The merge of convenience and cool!*

Hovercraft! is a tool to make impress.js_ presentations from
reStructuredText. For a quick explanation, see the demo_.

Features
--------

* Write your presentations in a text markup language. No slow, limiting GUI, no annoying HTML!

* Pan, rotate and zoom in 3D, with automatic repositioning of slides!

* A presenter console with notes and slide previews!

* The slide show generated is in HTML, so you only need a web browser to show it.

* Easy sharing, as it can be put up on a website for anyone to see!

Full documentation is available at readthedocs.org_, and also in the
documentation subdirectory.

Installation
------------

Hovercraft requires Python 3.2 or later, and can be installed like any Python package.
The easiest way is to install pip_, and then run::

    $ pip3 install hovercraft

Hovercraft is untested on Windows, but there is no reason it shouldn't work, at least in theory.


Contributors
------------

Hovercraft! was written by Lennart Regebro <regebro@gmail.com>, and is licensed
as CC-0, except for the following:

* ``reST.xsl`` is (c) Michael Alyn Miller <malyn@strangeGizmo.com> and
  published under a BSD-style license included in reST.xsl itself.

* ``impress.js`` is (c) Bartek Szopka (@bartaz) released under MIT and GPL
  licenses. See the impress.js_ page for more information.

Other contributors (see CHANGES.txt for details):

* Carl Meyer [carljm]

* Chris Withers [cjw296]

* Fahrzin Hemmati [fahhem]

* Christophe Labouisse [ggtools]

.. _impress.js: http://github.com/bartaz/impress.js
.. _demo: http://regebro.github.com/hovercraft
.. _readthedocs.org: https://hovercraft.readthedocs.org/
.. _pip: http://www.pip-installer.org/en/latest/

Changes
=======

2.0 (2015-06-14)
----------------

- Better support for :class:. [fahhem]

- Now supports data-perspective. [fahhem]

- Fixed typos in template.py. [fahhem, ggtools]


2.0b1 (2014-11-27)
------------------

- IMPORTANT! The positioning has been reimplemented. The most important change
  is that there is no longer any calculation of relative movement when you use
  absolute coordinates. Therefore, if you use absolute coordinates on some slides
  and then have no coordinates on other slides, your positioning may no longer
  be correct with version 2.0.

- IMPORTANT! Moved the "note" XML transformation into the templates, as this is an
  impress.js feature, and other libraries, such as Reveal.js, will render it
  differently. If you make your own templates, you need to update them accordingly!

- Relative coordinates (starting with r) are now supported for all positioning,
  attributes including rotation and scaling.

- Now includes a server-mode, that will serve the presentation via http and
  also re-generate the presentation if the source-files change.

- Images can now also have a :class: attribute.

- Added support for multiple levels of slides. This is to make it able
  to support for example Reveal.js through external templates.


1.1 (2013-03-15)
----------------

- ReST comments are no longer rendered to HTML. [carljm]

- Fixed a bug in the path handling for CSS resources. [carljm]

- Various fixes and improvements in ReST handling. [cjw296]


1.0 (2013-02-22)
----------------

- #1, #2: Add key-binding to pop up the help, a parameter and a presentation
  field setting to not show the help at load.

- Added documentation for #8: Naming steps.

- #7: You can now define CSS-files to be included with a :css:-field in the
  presentation.

- #3: You can now leave out the presenter notes from the output with the
  parameter -n or --skip-notes

- Added a "simple" template that has no presenter console.

- Updated to impress-console 1.1, fixing a Firefox bug.

- Added support for more HTML metadata.

- Finished documentation and examples.


1.0b2 (2013-02-13)
------------------

- Added syntax highlighting support.

- #9: All positioning variables except data-x and data-y are now "sticky" so
      they will keep their previous value if not defined.

- Documentation on https://hovercraft.readthedocs.org/


1.0b1 (2013-02-07)
------------------

- Initial release.


