----

.. container:: my-class

  This is some text in the container

.. container::
  :name: my-thing

  This should have an id

