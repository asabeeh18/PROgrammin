----

.. class:: my-class

  This is some text in the class
