:css: css/sub.css

---

This presentation uses a CSS file in a subdirectory which references external
resource files (c.f. issue GH-16).
